export default function footer(){
    return( 
    <div className="login-footer">
        Have Questions? <a href="#">Talk to our team</a>
        <br />
        <span>CloudKeeper 2025 | All Rights Reserved</span>
      </div>);
}
